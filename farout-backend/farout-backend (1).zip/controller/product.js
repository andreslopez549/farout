const express = require('express');
const productmodel = require('../models/product');
const fs =require('fs');
const path = require('path');



const create = async  (req, res, next) => {
    const product_images = [];
   
    try {
          console.log(req.body)
        const { name, imagelink, categories,price,brand } = req.body;
        let product = await productmodel.findOne({ name });
        if (product) {
            return res
                .status(400)
                .json({ errors: [{ msg: 'Product already exists' }] });
        }
      
            if(req.files){
                req.files.forEach(file => {
                    product_images.push(file.filename);
                  });
                  req.body.images=product_images
            }
             
        product = new productmodel(
            req.body
        );

        await product.save();
        return res.json({ message: "Product Created Successfully", data: product });

    }
    catch (err) {
        console.error(err.message);
        return res.status(500).send('Server error');
    }

};

const getById = async (req, res, next) => {
    const id = req.params.objectId;
 
    const product = await productmodel.findOne({ _id:id });

        if (!product) {
        return res.status(404).send('Product not found')
      }
    res.json({message: "Product Fetched Successfully", product: product})

}

const getall = async (req, res, next) => {
    const product = await productmodel.find({});
    res.json({message: "All Product Fetched Successfully", product: product})
}

const getcount = async (req, res, next) => {
    const product = await productmodel.find({});
    res.json({totalProducts: product.length})
}

const getmensproduct = async (req, res, next) => {
    const product = await productmodel.find({"type":"Men"});
    res.json({message: "All Product Fetched Successfully", product: product})
}
const getwomensproduct = async (req, res, next) => {
    const product = await productmodel.find({"type":"Women"});
    res.json({message: "All Product Fetched Successfully", product: product})
}
const getkidsproduct = async (req, res, next) => {
    const product = await productmodel.find({"type":"Kids"});
    res.json({message: "All Product Fetched Successfully", product: product})
}



module.exports = {
    create,
    getById,
    getall,
    getcount,
    getmensproduct,
    getwomensproduct,
    getkidsproduct
}